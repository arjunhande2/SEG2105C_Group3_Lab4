# Calcoolator

Creators: Abdullah Zubair, Arjun Hande, Shuvam Pathak


<!--Please watch the [demo video]() first.-->

Download the v1.0.1 APK [here](https://github.com/zahinabrer5/SEG2105C-Group3-Lab1/releases/download/v1.0.1/Calcoolator_v1.0.1.apk).
This is NOT necessarily the latest version of the project (please see the source code).

